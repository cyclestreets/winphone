﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

using System.Collections.Generic;
using System.Device.Location;
using Cyclestreets.Utils;
using GalaSoft.MvvmLight;
using Microsoft.Phone.Maps.Toolkit;
namespace Cyclestreets.ViewModel
{
	public class DirectionsPageViewModel : ViewModelBase
	{
		
		public DirectionsPageViewModel()
		{
			if( IsInDesignMode )
			{

			}
			else
			{
			
			}
		}

		
	}
}
