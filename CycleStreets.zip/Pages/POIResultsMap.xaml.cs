﻿using System;
using System.Collections.Generic;
using System.Device.Location;
using System.Linq;
using System.Net;
using System.Text;
using System.Windows;
using System.Windows.Media;
using System.Xml.Linq;
using Microsoft.Expression.Interactivity.Core;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Maps.Controls;
using Microsoft.Phone.Maps.Services;
using Microsoft.Phone.Shell;
using Windows.Devices.Geolocation;

namespace Cyclestreets
{
	public partial class POIResultsMap : PhoneApplicationPage
	{
		
		// Constructor
		public POIResultsMap()
		{
			InitializeComponent();
			
		}

		
	}
}