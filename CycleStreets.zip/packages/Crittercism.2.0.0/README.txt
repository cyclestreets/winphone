Thanks for installing Crittercism's Windows Phone 8 SDK!

Now all you need to do is:
1) Sign up for an account with Crittercism:
     https://www.crittercism.com/sign-up/
   Don't worry, it's free to sign up and we don't send spam.
2) Register your app with Crittercism; we'll give you an appId.
3) Add a call to CrittercismSDK.Crittercism.Init() with your appId.
   The best place is probably your Application_Launching() method.

That's it!  You can read more about our SDK including features like
breadcrumbs and handled exception logging in the Documentation section
of your Crittercism account:
    https://app.crittercism.com/developers/docs-wp
