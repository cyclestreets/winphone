<?php
/*********************************************************
 * $HeadURL: http://www.maidenfans.com/svn/rwdownload_new/TRUNK/functions/rwd_constants.php $
 * $Revision: 50 $
 * $LastChangedBy: realworld $
 * $LastChangedDate: 2008-12-20 20:32:52 +0000 (Sat, 20 Dec 2008) $
 *********************************************************/

define('DEBUG',     0);
define('ROOT_PATH', "./" );
define('DEV_MODE', 0);

// Set warning level
error_reporting  ( E_ERROR | E_WARNING | E_PARSE );
set_magic_quotes_runtime(0);

?>