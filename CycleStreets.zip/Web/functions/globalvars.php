<?php
$CONFIG['sqldatabase'] = 'rwscript_cyclestreets';
$CONFIG['sqlhost'] = 'localhost';
$CONFIG['sqlpassword'] = '1xb!]~0q7cwn';
$CONFIG['sqlprefix'] = '';
$CONFIG['sqlusername'] = 'rwscript_cycle';
?>
