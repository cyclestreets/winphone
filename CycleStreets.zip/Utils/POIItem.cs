﻿
namespace Cyclestreets.Utils
{
	public class POIItem
	{
		public string POILabel
		{
			get;
			set;
		}
		public bool POIEnabled
		{
			get;
			set;
		}
		public string POIName
		{
			get;
			set;
		}
	}
}
